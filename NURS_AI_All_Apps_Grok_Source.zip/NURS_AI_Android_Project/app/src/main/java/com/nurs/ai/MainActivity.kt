package com.nurs.ai

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var status: TextView
    private lateinit var resultText: TextView
    private lateinit var listenButton: Button
    private lateinit var wakeButton: Button
    private lateinit var langButton: Button
    private lateinit var input: EditText

    private val bg = Color.rgb(4, 10, 12)
    private val neon = Color.rgb(0, 255, 145)
    private val pale = Color.rgb(170, 220, 200)
    private val panel = Color.rgb(12, 28, 26)

    private var useKyrgyz = true          // ky-KG or ru-RU recognition
    private var wakeMode = false          // "Hey Nurs" mode (only while the app is open)
    private var awaitingCommand = false
    private var listening = false
    private val prefs by lazy { getSharedPreferences("nurs", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        setupRecognizer()
        requestMic()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp() = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(6)) }

    private fun neonButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; setTextColor(Color.BLACK); setBackgroundColor(neon); setOnClickListener { onClick() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(28), dp(16), dp(20))
            setBackgroundColor(bg)
        }
        root.addView(TextView(this).apply {
            text = "NURS AI"; textSize = 34f; letterSpacing = .2f
            gravity = Gravity.CENTER; setTextColor(neon); typeface = android.graphics.Typeface.MONOSPACE
        }, lp())
        root.addView(TextView(this).apply {
            text = "PERSONAL VOICE ASSISTANT"; textSize = 11f
            gravity = Gravity.CENTER; setTextColor(pale)
        }, lp())
        status = TextView(this).apply {
            text = "● SYSTEM READY"; textSize = 15f; gravity = Gravity.CENTER
            setTextColor(neon); typeface = android.graphics.Typeface.MONOSPACE
        }
        root.addView(status, lp())
        listenButton = neonButton("🎙 TALK TO NURS") { startListening() }
        root.addView(listenButton, lp())
        wakeButton = neonButton("HEY NURS: OFF") { toggleWake() }
        root.addView(wakeButton, lp())
        langButton = neonButton("ТИЛ: КЫРГЫЗЧА (ky-KG)") { toggleLang() }
        root.addView(langButton, lp())
        root.addView(neonButton("⚙ AI СЕРВЕР (URL)") { askServerUrl() }, lp())

        input = EditText(this).apply {
            hint = "Текст жазып AI менен сүйлөш..."; setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE); setBackgroundColor(panel); setPadding(dp(12), dp(10), dp(12), dp(10))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        root.addView(input, lp())
        root.addView(neonButton("ЖӨНӨТ") {
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) { input.setText(""); resultText.text = "СЕН: $t"; handleCommand(t) }
        }, lp())

        root.addView(TextView(this).apply {
            text = "БУЙРУКТАР:\n• Hey Nurs (кошумча режимде)\n• YouTube ач / Ютуб ач\n• Камераны ач\n• Телефонду ач\n" +
                "• WhatsApp ... (текст даярдайт)\n• Башка сөз → AI жооп берет"
            textSize = 14f; setTextColor(pale)
        }, lp())
        resultText = TextView(this).apply {
            text = "Сенин буйругуң ушул жерде көрүнөт."
            textSize = 16f; setTextColor(Color.WHITE); setPadding(dp(12), dp(14), dp(12), dp(14))
            setBackgroundColor(panel); minHeight = dp(140)
        }
        root.addView(resultText, lp())
        setContentView(ScrollView(this).apply { setBackgroundColor(bg); addView(root) })
    }

    // ---------- Permissions ----------
    private fun hasMic() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun requestMic() {
        if (!hasMic()) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 101)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 101 && !(res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED))
            status.text = "● МИКРОФОН УРУКСАТЫ БЕРИЛГЕН ЖОК"
    }

    // ---------- Speech recognition ----------
    private fun setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "ҮН ТААНУУ КЫЗМАТЫ ЖОК (Google/Samsung)"
            listenButton.isEnabled = false; wakeButton.isEnabled = false; return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "● УГУП ЖАТАМ..." }
            override fun onBeginningOfSpeech() { status.text = "● СҮЙЛӨП ЖАТАСЫҢ..." }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "● ИШТЕТИП ЖАТАМ..." }
            override fun onError(error: Int) {
                listening = false; listenButton.isEnabled = true
                if (error == 12 || error == 13) { // LANGUAGE_NOT_SUPPORTED / UNAVAILABLE
                    wakeMode = false; wakeButton.text = "HEY NURS: OFF"
                    status.text = "Бул тил телефонуңда колдоого алынбайт. «ТИЛ» баскычы менен орусчага өт."
                    return
                }
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    wakeMode = false; wakeButton.text = "HEY NURS: OFF"; status.text = "Микрофон уруксаты жок"; return
                }
                status.text = if (wakeMode) "● HEY NURS КҮТӨМ..." else "КАТА ($error). КАЙРА БАС."
                if (wakeMode) restartSoon()
            }
            override fun onResults(results: Bundle?) {
                listening = false; listenButton.isEnabled = true
                val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (wakeMode) onWakeResult(phrase) else {
                    resultText.text = "СЕН: $phrase"; if (phrase.isNotBlank()) handleCommand(phrase)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun startListening() {
        if (!hasMic()) { requestMic(); return }
        if (listening) return
        val tag = if (useKyrgyz) "ky-KG" else "ru-RU"
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tag)
        }
        tts?.stop()
        listening = true; listenButton.isEnabled = false
        try { recognizer?.startListening(intent) } catch (e: Exception) {
            listening = false; listenButton.isEnabled = true; status.text = "Угуу башталган жок"
        }
    }

    private fun restartSoon() = ui.postDelayed({ if (wakeMode && !listening && !isFinishing) startListening() }, 800)

    private fun toggleLang() {
        useKyrgyz = !useKyrgyz
        langButton.text = if (useKyrgyz) "ТИЛ: КЫРГЫЗЧА (ky-KG)" else "ТИЛ: ОРУСЧА (ru-RU)"
        pickTtsLanguage()
    }

    // ---------- "Hey Nurs" (works only while the app is open on screen) ----------
    private fun toggleWake() {
        wakeMode = !wakeMode; awaitingCommand = false
        wakeButton.text = if (wakeMode) "HEY NURS: ON (экран ачык)" else "HEY NURS: OFF"
        if (wakeMode) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            status.text = "● HEY NURS КҮТӨМ..."; startListening()
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            recognizer?.cancel(); listening = false; status.text = "● SYSTEM READY"
        }
    }

    private val wakeWords = listOf("hey nurs", "hey nurse", "hey nours", "хей нурс", "хэй нурс", "эй нурс", "хей нурс", "салам нурс", "hey nur")

    private fun onWakeResult(phrase: String) {
        val lower = phrase.lowercase(Locale.ROOT).trim()
        if (awaitingCommand) {
            awaitingCommand = false
            if (lower.isNotEmpty()) { resultText.text = "СЕН: $phrase"; handleCommand(phrase) }
            restartAfterSpeech(); return
        }
        val w = wakeWords.firstOrNull { lower.contains(it) }
        if (w == null) { restartSoon(); return }
        val rest = lower.substringAfter(w).trim()
        if (rest.isEmpty()) { awaitingCommand = true; say("Угуп жатам"); restartAfterSpeech() }
        else { resultText.text = "СЕН: $phrase"; handleCommand(rest); restartAfterSpeech() }
    }

    private fun restartAfterSpeech() = ui.postDelayed({ if (wakeMode && !listening && !isFinishing) startListening() }, 2500)

    // ---------- Commands ----------
    private fun handleCommand(raw: String) {
        val s = raw.lowercase(Locale.ROOT)
        when {
            s.contains("whatsapp") || s.contains("вотсап") || s.contains("ватсап") || s.contains("уотсап") -> prepareWhatsApp(raw)
            s.contains("youtube") || s.contains("ютуб") || s.contains("ютюб") -> openYouTube()
            s.contains("камера") -> openCamera()
            s.contains("телефон") || s.contains("чалуу") || s.contains("звон") -> openDialer()
            s.contains("жөндөө") || s.contains("настрой") -> openSettings()
            s.contains("telegram") || s.contains("телеграм") -> openNamedApp(listOf("org.telegram.messenger"), "Telegram")
            s.contains("snapchat") || s.contains("снэпчат") || s.contains("снапчат") -> openNamedApp(listOf("com.snapchat.android"), "Snapchat")
            s.contains("free fire") || s.contains("freefire") || s.contains("фри фаер") || s.contains("фф ач") -> openNamedApp(listOf("com.dts.freefireth", "com.dts.freefiremax"), "Free Fire")
            s.contains("instagram") || s.contains("инстаграм") -> openNamedApp(listOf("com.instagram.android"), "Instagram")
            s.contains("tiktok") || s.contains("тикток") -> openNamedApp(listOf("com.zhiliaoapp.musically"), "TikTok")
            s.contains("facebook") || s.contains("фейсбук") -> openNamedApp(listOf("com.facebook.katana"), "Facebook")
            s.contains("chrome") || s.contains("хром") -> openNamedApp(listOf("com.android.chrome"), "Chrome")
            s.contains("gmail") || s.contains("почта") -> openNamedApp(listOf("com.google.android.gm"), "Gmail")
            s.contains("галерея") || s.contains("gallery") -> openNamedApp(listOf("com.google.android.apps.photos", "com.sec.android.gallery3d"), "Галерея")
            s.contains("play market") || s.contains("плей маркет") -> openNamedApp(listOf("com.android.vending"), "Play Market")
            s.contains("бардык тиркем") || s.contains("бардык приложени") -> showLaunchableApps()
            else -> {
                val appName = raw.lowercase(Locale.ROOT)
                    .replace("нурс", "").replace("hey", "")
                    .replace(Regex("ачып бер|ач|открой|открыть|запусти|запустить|иштет"), "")
                    .trim(' ', ',', '.', '!', '?')
                if (appName.isNotBlank() && tryOpenInstalledApp(appName)) return
                askAi(raw)
            }
        }
    }

    private fun openNamedApp(packages: List<String>, title: String) {
        for (pkg in packages) {
            val launch = packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                say("$title ачып жатам.")
                try { startActivity(launch); return } catch (_: Exception) {}
            }
        }
        say("$title телефонуңда орнотулган эмес окшойт.")
    }

    private fun tryOpenInstalledApp(name: String): Boolean {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val target = packageManager.queryIntentActivities(intent, 0).firstOrNull {
            it.loadLabel(packageManager).toString().contains(name, ignoreCase = true)
        } ?: return false
        val launch = packageManager.getLaunchIntentForPackage(target.activityInfo.packageName) ?: return false
        return try { startActivity(launch); say("${target.loadLabel(packageManager)} ачып жатам."); true }
        catch (_: Exception) { false }
    }

    private fun showLaunchableApps() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val names = packageManager.queryIntentActivities(intent, 0)
            .map { it.loadLabel(packageManager).toString() }.distinct().sorted()
        AlertDialog.Builder(this).setTitle("Телефондогу колдонмолор")
            .setItems(names.toTypedArray()) { _, which -> tryOpenInstalledApp(names[which]) }
            .setNegativeButton("Жабуу", null).show()
    }

    private fun openYouTube() {
        val i = packageManager.getLaunchIntentForPackage("com.google.android.youtube")
        try {
            if (i != null) { say("YouTube ачып жатам."); startActivity(i) }
            else { say("YouTube браузерден ачылууда."); startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))) }
        } catch (e: Exception) { say("YouTube ача алган жокмун.") }
    }

    private fun openCamera() {
        try { say("Камераны ачып жатам."); startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
        catch (e: Exception) { say("Камераны ача алган жокмун.") }
    }

    private fun openDialer() {
        try { say("Телефон тергичин ачып жатам."); startActivity(Intent(Intent.ACTION_DIAL)) }
        catch (e: Exception) { say("Телефонду ача алган жокмун.") }
    }

    private fun openSettings() {
        try { say("Жөндөөлөрдү ачып жатам."); startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
        catch (e: Exception) { say("Жөндөөлөрдү ача алган жокмун.") }
    }

    // WhatsApp: only prepares the text. The user picks the contact and presses Send in WhatsApp.
    private fun prepareWhatsApp(raw: String) {
        val text = raw.replace(Regex("(?i)whatsapp|вотсап|ватсап|уотсап"), "")
            .replace(Regex("(?i)(аркылуу|жаз|жазып|билдирүү|жөнөт|даярда|напиши|отправь)"), "").trim(' ', ',', '.', ':')
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text.ifEmpty { "" })
        }
        try {
            val wa = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull {
                try { packageManager.getPackageInfo(it, 0); true } catch (e: Exception) { false }
            }
            if (wa != null) send.setPackage(wa)
            say("WhatsApp ачылды. Байланышты тандап, жөнөтүүнү өзүң бас.")
            startActivity(if (wa != null) send else Intent.createChooser(send, "WhatsApp"))
        } catch (e: ActivityNotFoundException) { say("WhatsApp табылган жок.") }
    }

    // ---------- AI chat via YOUR backend proxy (no API key stored in the APK) ----------
    private fun askServerUrl() {
        val et = EditText(this).apply { setText(prefs.getString("url", "")); hint = "https://your-server.example/chat" }
        AlertDialog.Builder(this).setTitle("AI сервер URL (https)").setView(et)
            .setPositiveButton("Сактоо") { _, _ -> prefs.edit().putString("url", et.text.toString().trim()).apply() }
            .setNegativeButton("Жок", null).show()
    }

    private fun askAi(question: String) {
        val url = prefs.getString("url", "").orEmpty()
        if (!url.startsWith("https://")) {
            say("AI сервер дареги жок. Жогорудагы AI СЕРВЕР баскычы менен https дарек киргиз."); return
        }
        status.text = "● AI ОЙЛОНУП ЖАТАТ..."
        Thread {
            val reply = try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 45000
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8"); c.doOutput = true
                c.outputStream.use { it.write(JSONObject().put("message", question).put("lang", "ky").toString().toByteArray()) }
                if (c.responseCode !in 200..299) "Сервер ката кайтарды (${c.responseCode})."
                else JSONObject(c.inputStream.bufferedReader().readText()).optString("reply", "Бош жооп келди.")
            } catch (e: Exception) { "Серверге туташа алган жокмун." }
            runOnUiThread { if (!isFinishing) { resultText.text = "NURS: $reply"; say(reply) } }
        }.start()
    }

    // ---------- Text to speech ----------
    private fun say(message: String) {
        status.text = "NURS: $message"
        if (ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "nurs_reply")
    }

    override fun onInit(code: Int) {
        ttsReady = code == TextToSpeech.SUCCESS
        if (ttsReady) pickTtsLanguage()
    }

    private fun pickTtsLanguage() {
        val t = tts ?: return
        val ky = Locale.forLanguageTag("ky-KG")
        val ok = { r: Int -> r >= TextToSpeech.LANG_AVAILABLE }
        when {
            useKyrgyz && ok(t.isLanguageAvailable(ky)) -> t.language = ky
            ok(t.isLanguageAvailable(Locale.forLanguageTag("ru-RU"))) -> {
                t.language = Locale.forLanguageTag("ru-RU")
                if (useKyrgyz) resultText.text = "Эскертүү: телефондо кыргызча TTS үнү жок, орусча үн колдонулат."
            }
            else -> t.language = Locale.getDefault()
        }
    }

    override fun onPause() {
        if (wakeMode) toggleWake()   // never listen in the background
        super.onPause()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        recognizer?.destroy(); tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }
}
