// NURS AI -> xAI (Grok) proxy for Cloudflare Workers.
// Store XAI_API_KEY as a Worker secret. Never put it in the Android APK.
export default {
  async fetch(request, env) {
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    const json = (data, status = 200) => new Response(JSON.stringify(data), {
      status, headers: { ...cors, "Content-Type": "application/json; charset=utf-8" }
    });
    if (request.method !== "POST") return json({ error: "Use POST /chat" }, 405);
    if (!env.XAI_API_KEY) return json({ reply: "Grok API ачкычы серверде орнотулган эмес." }, 503);

    try {
      const body = await request.json();
      const message = typeof body.message === "string" ? body.message.trim() : "";
      const lang = body.lang === "ru" ? "ru" : "ky";
      if (!message) return json({ reply: "Суроо бош болбошу керек." }, 400);
      if (message.length > 4000) return json({ reply: "Суроо өтө узун. Кыскартып жибер." }, 413);

      const system = lang === "ru"
        ? "Ты NURS AI, полезный и безопасный помощник. Отвечай ясно и кратко на русском языке."
        : "Сен NURS AI жардамчысысың. Так, түшүнүктүү жана коопсуз жооп бер. Кыргызча жооп бер.";

      const upstream = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${env.XAI_API_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: "grok-4.7",
          messages: [
            { role: "system", content: system },
            { role: "user", content: message }
          ],
          max_tokens: 700
        })
      });
      const data = await upstream.json().catch(() => ({}));
      if (!upstream.ok) {
        return json({ reply: `Grok серверинде ката чыкты (${upstream.status}).` }, 502);
      }
      const reply = data?.choices?.[0]?.message?.content;
      if (typeof reply !== "string" || !reply.trim()) {
        return json({ reply: "Grok бош жооп берди." }, 502);
      }
      return json({ reply: reply.trim() });
    } catch (_) {
      return json({ reply: "Сурамды иштетүүдө ката чыкты." }, 400);
    }
  }
};
