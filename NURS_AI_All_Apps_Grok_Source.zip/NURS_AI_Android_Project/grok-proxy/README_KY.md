# NURS AI — Grok сервери

Бул сервер Android колдонмосуна `{"message":"...","lang":"ky"}` кабыл алып,
`{"reply":"..."}` кайтарат. xAI API ачкычы APK ичине салынбайт.

## Орнотуу
1. Cloudflare аккаунтуңда жаңы Worker түз.
2. `worker.js` кодун Worker'ге көчүр.
3. Worker Settings → Variables and Secrets бөлүмүндө `XAI_API_KEY` деген **Secret** түзүп,
   жаңы API ачкычты ошол жерге киргиз. Эски чатка түшүп калган ачкычты колдонбо.
4. Worker'ди Deploy кыл.
5. Worker'дин HTTPS дарегин NURS AI колдонмосундагы **AI СЕРВЕР (URL)** баскычына киргизип,
   аягына `/` кошпостон `/chat` жолун кош: `https://<worker-domain>/chat`.

Эскертүү: xAI API колдонуу акы төлөнүүчү болушу мүмкүн. Чыгымдарды жана жеткиликтүү моделдерди
xAI Console'дон текшер. API ачкычын эч кимге жибербе.
